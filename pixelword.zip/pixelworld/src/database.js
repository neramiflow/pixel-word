/**
 * database.js — Initialisation et accès à la base SQLite via sql.js
 * Stockage sur disque en JSON pour la persistance (sql.js est en mémoire)
 */

const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../db/pixelworld.json');

// Structure de la base de données en mémoire
let db = {
  users: [],        // { id, pseudo, password_hash, sprite, created_at }
  houses: [],       // { id, user_id, x, y, world_id }
  worlds: [],       // { id, owner_id, name, type, created_at }
  tiles: [],        // { id, world_id, x, y, layer, tile_type, tile_data }
  codenet_posts: [] // { id, user_id, world_id, title, code, created_at }
};

/** Charger la DB depuis le disque */
function loadDb() {
  if (fs.existsSync(DB_PATH)) {
    try {
      const raw = fs.readFileSync(DB_PATH, 'utf-8');
      db = JSON.parse(raw);
      // S'assurer que toutes les tables existent
      if (!db.users) db.users = [];
      if (!db.houses) db.houses = [];
      if (!db.worlds) db.worlds = [];
      if (!db.tiles) db.tiles = [];
      if (!db.codenet_posts) db.codenet_posts = [];
      console.log('[DB] Base chargée depuis le disque.');
    } catch (e) {
      console.error('[DB] Erreur de lecture, réinitialisation.', e);
    }
  } else {
    console.log('[DB] Nouvelle base créée.');
  }
}

/** Sauvegarder la DB sur le disque */
function saveDb() {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

// ─── USERS ────────────────────────────────────────────────────────────────────

function getUserById(id) {
  return db.users.find(u => u.id === id) || null;
}

function getUserByPseudo(pseudo) {
  return db.users.find(u => u.pseudo.toLowerCase() === pseudo.toLowerCase()) || null;
}

function createUser(id, pseudo, passwordHash) {
  const user = { id, pseudo, password_hash: passwordHash, sprite: null, created_at: Date.now() };
  db.users.push(user);
  saveDb();
  return user;
}

function updateUserSprite(userId, spriteData) {
  const user = db.users.find(u => u.id === userId);
  if (user) {
    user.sprite = spriteData;
    saveDb();
  }
}

// ─── HOUSES ───────────────────────────────────────────────────────────────────

function getHouseByUser(userId) {
  return db.houses.find(h => h.user_id === userId) || null;
}

function getHouseByPos(x, y) {
  return db.houses.find(h => h.x === x && h.y === y) || null;
}

function getAllHouses() {
  return db.houses;
}

function createHouse(id, userId, x, y, worldId) {
  const house = { id, user_id: userId, x, y, world_id: worldId };
  db.houses.push(house);
  saveDb();
  return house;
}

// ─── WORLDS ───────────────────────────────────────────────────────────────────

function getWorldById(id) {
  return db.worlds.find(w => w.id === id) || null;
}

function getWorldsByOwner(ownerId) {
  return db.worlds.filter(w => w.owner_id === ownerId);
}

function createWorld(id, ownerId, name, type) {
  const world = { id, owner_id: ownerId, name, type, created_at: Date.now() };
  db.worlds.push(world);
  saveDb();
  return world;
}

// ─── TILES ────────────────────────────────────────────────────────────────────

function getTilesByWorld(worldId) {
  return db.tiles.filter(t => t.world_id === worldId);
}

function setTile(worldId, x, y, layer, tileType, tileData) {
  // Supprimer l'ancienne tuile si elle existe
  db.tiles = db.tiles.filter(t => !(t.world_id === worldId && t.x === x && t.y === y && t.layer === layer));
  if (tileType !== null) {
    const tile = { id: `${worldId}_${x}_${y}_${layer}`, world_id: worldId, x, y, layer, tile_type: tileType, tile_data: tileData };
    db.tiles.push(tile);
  }
  saveDb();
}

function deleteTile(worldId, x, y, layer) {
  db.tiles = db.tiles.filter(t => !(t.world_id === worldId && t.x === x && t.y === y && t.layer === layer));
  saveDb();
}

// ─── CODENET ──────────────────────────────────────────────────────────────────

function getAllCodenetPosts() {
  return db.codenet_posts.sort((a, b) => b.created_at - a.created_at);
}

function createCodenetPost(id, userId, worldId, title, code) {
  const post = { id, user_id: userId, world_id: worldId, title, code, created_at: Date.now() };
  db.codenet_posts.push(post);
  saveDb();
  return post;
}

// ─── INIT ─────────────────────────────────────────────────────────────────────

loadDb();

module.exports = {
  getUserById, getUserByPseudo, createUser, updateUserSprite,
  getHouseByUser, getHouseByPos, getAllHouses, createHouse,
  getWorldById, getWorldsByOwner, createWorld,
  getTilesByWorld, setTile, deleteTile,
  getAllCodenetPosts, createCodenetPost
};
