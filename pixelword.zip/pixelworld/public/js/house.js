/**
 * house.js — Maison personnelle + éditeur de tuiles
 */

const House = (() => {
  const MAP_W = 20, MAP_H = 15;
  const TILE = 32;

  // Palette de tuiles
  const FLOOR_TILES = [
    { id: 'grass',    emoji: '🟩', color: '#2d7a2d', label: 'Herbe' },
    { id: 'dirt',     emoji: '🟫', color: '#8b6340', label: 'Terre' },
    { id: 'stone',    emoji: '⬜', color: '#888899', label: 'Pierre' },
    { id: 'wood',     emoji: '🟧', color: '#a0643c', label: 'Bois' },
    { id: 'water',    emoji: '🟦', color: '#1a5fa0', label: 'Eau' },
    { id: 'sand',     emoji: '🟨', color: '#c8a84b', label: 'Sable' },
    { id: 'road',     emoji: '⬛', color: '#444455', label: 'Route' },
    { id: 'carpet',   emoji: '🔴', color: '#c0392b', label: 'Tapis' },
  ];

  const OBJECT_TILES = [
    { id: 'tree',     emoji: '🌲', color: '#1a6b1a', label: 'Arbre' },
    { id: 'flower',   emoji: '🌸', color: '#ff9ec4', label: 'Fleur' },
    { id: 'rock',     emoji: '🪨', color: '#777788', label: 'Rocher' },
    { id: 'fence',    emoji: '🚧', color: '#9b7653', label: 'Barrière' },
    { id: 'computer', emoji: '💻', color: '#334466', label: 'Ordi' },
    { id: 'chest',    emoji: '📦', color: '#c8a84b', label: 'Coffre' },
    { id: 'plant',    emoji: '🪴', color: '#2a8c2a', label: 'Plante' },
    { id: 'lamp',     emoji: '🔆', color: '#ffe066', label: 'Lampe' },
  ];

  let canvas, ctx;
  let camera = { x: 0, y: 0 };
  let currentHouse = null;
  let currentWorldId = null;
  let floorTiles = {};   // "x,y" → tileId
  let objectTiles = {};  // "x,y" → tileId
  let players = new Map();
  let myPos = { x: 5, y: 5 };
  let editorLayer = 'floor';
  let selectedTile = null;
  let currentTool = 'place';
  let isPlacing = false;
  let keys = {};

  function init(canvasEl) {
    canvas = canvasEl;
    ctx = canvas.getContext('2d');

    canvas.addEventListener('mousedown', e => { isPlacing = true; handleCanvasAction(e); });
    canvas.addEventListener('mousemove', e => { if (isPlacing) handleCanvasAction(e); });
    canvas.addEventListener('mouseup',   () => isPlacing = false);
    canvas.addEventListener('mouseleave',() => isPlacing = false);

    document.addEventListener('keydown', e => {
      if (document.getElementById('screen-house').classList.contains('active')) {
        keys[e.key] = true;
        handleKeyMove(e.key);
        if (e.key === 'Enter' || e.key === ' ') checkInteract();
      }
    });
    document.addEventListener('keyup', e => keys[e.key] = false);

    buildTilePalette();
  }

  function handleKeyMove(key) {
    switch(key) {
      case 'ArrowUp':    case 'z': case 'Z': moveMe(0,-1); break;
      case 'ArrowDown':  case 's': case 'S': moveMe(0,1);  break;
      case 'ArrowLeft':  case 'q': case 'Q': moveMe(-1,0); break;
      case 'ArrowRight': case 'd': case 'D': moveMe(1,0);  break;
    }
  }

  function enter(house) {
    currentHouse = house;
    currentWorldId = house.world_id;
    floorTiles = {};
    objectTiles = {};
    players.clear();
    document.getElementById('house-world-name').textContent = `🏠 ${house.pseudo}`;
    showScreen('house');
    loadWorldData();
    WS.send({ type: 'ENTER_WORLD', worldId: house.world_id });
    startLoop();
  }

  async function loadWorldData() {
    const res = await API.get(`/api/worlds/${currentWorldId}`);
    if (res.error) { toast(res.error, true); return; }
    floorTiles = {};
    objectTiles = {};
    res.tiles.forEach(t => {
      const key = `${t.x},${t.y}`;
      if (t.layer === 'floor') floorTiles[key] = t.tile_type;
      else objectTiles[key] = t.tile_type;
    });
  }

  function buildTilePalette() {
    renderTilePalette();
  }

  function renderTilePalette() {
    const tiles = editorLayer === 'floor' ? FLOOR_TILES : OBJECT_TILES;
    const container = document.getElementById('tile-palette');
    if (!container) return;
    container.innerHTML = '';
    tiles.forEach(t => {
      const btn = document.createElement('div');
      btn.className = 'tile-btn' + (selectedTile === t.id ? ' selected' : '');
      btn.title = t.label;
      btn.textContent = t.emoji;
      btn.onclick = () => {
        selectedTile = t.id;
        renderTilePalette();
      };
      container.appendChild(btn);
    });
  }

  function setEditorLayer(layer) {
    editorLayer = layer;
    selectedTile = null;
    document.querySelectorAll('.editor-mode-tabs .tab-btn').forEach(b => b.classList.remove('active'));
    event.target.classList.add('active');
    renderTilePalette();
  }

  function setTool(tool) {
    currentTool = tool;
    document.querySelectorAll('.tool-btn').forEach(b => b.classList.remove('active'));
    document.querySelector(`[data-tool="${tool}"]`)?.classList.add('active');
  }

  function handleCanvasAction(e) {
    const rect = canvas.getBoundingClientRect();
    const mx = (e.clientX - rect.left) * (canvas.width / rect.width);
    const my = (e.clientY - rect.top) * (canvas.height / rect.height);
    const tx = Math.floor((mx + camera.x) / TILE);
    const ty = Math.floor((my + camera.y) / TILE);

    if (tx < 0 || ty < 0 || tx >= MAP_W || ty >= MAP_H) return;

    // Vérifier clic sur ordinateur
    const key = `${tx},${ty}`;
    if (objectTiles[key] === 'computer') {
      openComputer();
      return;
    }

    if (!selectedTile && currentTool === 'place') return;

    const tileId = currentTool === 'erase' ? null : selectedTile;
    const layer = editorLayer;

    if (layer === 'floor') {
      if (tileId) floorTiles[key] = tileId;
      else delete floorTiles[key];
    } else {
      if (tileId) objectTiles[key] = tileId;
      else delete objectTiles[key];
    }

    // Sauvegarder sur le serveur
    API.post('/api/tiles', {
      worldId: currentWorldId,
      x: tx, y: ty, layer,
      tileType: tileId, tileData: null
    });
  }

  function applyTileUpdate(data) {
    const key = `${data.x},${data.y}`;
    if (data.layer === 'floor') {
      if (data.tileType) floorTiles[key] = data.tileType;
      else delete floorTiles[key];
    } else {
      if (data.tileType) objectTiles[key] = data.tileType;
      else delete objectTiles[key];
    }
  }

  function checkInteract() {
    // Ordinateur ?
    const key = `${myPos.x},${myPos.y}`;
    const neighbors = [key, `${myPos.x+1},${myPos.y}`, `${myPos.x-1},${myPos.y}`, `${myPos.x},${myPos.y+1}`, `${myPos.x},${myPos.y-1}`];
    for (const k of neighbors) {
      if (objectTiles[k] === 'computer') { openComputer(); return; }
    }
  }

  function moveMe(dx, dy) {
    const nx = myPos.x + dx;
    const ny = myPos.y + dy;
    if (nx < 0 || ny < 0 || nx >= MAP_W || ny >= MAP_H) return;
    myPos.x = nx;
    myPos.y = ny;
    updateCamera();
    WS.send({ type: 'MOVE', x: nx, y: ny });
  }

  function updateCamera() {
    const cw = canvas.width, ch = canvas.height;
    camera.x = myPos.x * TILE - cw / 2 + TILE / 2;
    camera.y = myPos.y * TILE - ch / 2 + TILE / 2;
    camera.x = Math.max(0, Math.min(MAP_W * TILE - cw, camera.x));
    camera.y = Math.max(0, Math.min(MAP_H * TILE - ch, camera.y));
  }

  // Obtenir la couleur d'une tuile par son id
  function getTileColor(tileId, layer) {
    const arr = layer === 'floor' ? FLOOR_TILES : OBJECT_TILES;
    return arr.find(t => t.id === tileId)?.color || '#2d5a27';
  }
  function getTileEmoji(tileId, layer) {
    const arr = layer === 'floor' ? FLOOR_TILES : OBJECT_TILES;
    return arr.find(t => t.id === tileId)?.emoji || null;
  }

  // ─── Rendu ──────────────────────────────────────────────

  let animFrame = null;
  function startLoop() {
    if (animFrame) cancelAnimationFrame(animFrame);
    function loop() {
      if (!document.getElementById('screen-house').classList.contains('active')) return;
      draw();
      animFrame = requestAnimationFrame(loop);
    }
    loop();
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(-camera.x, -camera.y);

    const startX = Math.floor(camera.x / TILE);
    const startY = Math.floor(camera.y / TILE);
    const endX = Math.min(MAP_W, startX + Math.ceil(canvas.width / TILE) + 2);
    const endY = Math.min(MAP_H, startY + Math.ceil(canvas.height / TILE) + 2);

    // Sol de base (murs de la maison)
    for (let y = 0; y < MAP_H; y++) {
      for (let x = 0; x < MAP_W; x++) {
        // Bordure
        const isBorder = x === 0 || y === 0 || x === MAP_W - 1 || y === MAP_H - 1;
        ctx.fillStyle = isBorder ? '#3a2010' : '#c8a87a';
        ctx.fillRect(x * TILE, y * TILE, TILE, TILE);
        if (!isBorder) {
          // Texture parquet
          ctx.strokeStyle = '#b89060';
          ctx.lineWidth = 0.5;
          ctx.strokeRect(x * TILE, y * TILE, TILE, TILE);
        }
      }
    }

    // Sol personnalisé
    for (const [key, tileId] of Object.entries(floorTiles)) {
      const [x, y] = key.split(',').map(Number);
      ctx.fillStyle = getTileColor(tileId, 'floor');
      ctx.fillRect(x * TILE, y * TILE, TILE, TILE);
    }

    // Objets
    for (const [key, tileId] of Object.entries(objectTiles)) {
      const [x, y] = key.split(',').map(Number);
      const emoji = getTileEmoji(tileId, 'object');
      if (emoji) {
        ctx.font = (TILE - 4) + 'px serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(emoji, x * TILE + TILE / 2, y * TILE + TILE / 2);
      } else {
        ctx.fillStyle = getTileColor(tileId, 'object');
        ctx.fillRect(x * TILE + 4, y * TILE + 4, TILE - 8, TILE - 8);
      }
    }

    // Mon joueur
    const me = window.currentUser;
    const px = myPos.x * TILE;
    const py = myPos.y * TILE;
    if (me?.sprite) {
      const sz = Math.sqrt(me.sprite.length);
      const scale = TILE / sz;
      me.sprite.forEach((color, i) => {
        if (!color) return;
        const sx = i % sz; const sy = Math.floor(i / sz);
        ctx.fillStyle = color;
        ctx.fillRect(px + sx * scale, py + sy * scale, scale, scale);
      });
    } else {
      ctx.fillStyle = '#43e89e';
      ctx.fillRect(px + 4, py + 4, TILE - 8, TILE - 8);
    }
    ctx.strokeStyle = '#43e89e';
    ctx.lineWidth = 2;
    ctx.strokeRect(px, py, TILE, TILE);

    // Autres joueurs dans la maison
    for (const [sid, p] of players) {
      if (p.isMe) continue;
      const bx = p.x * TILE, by = p.y * TILE;
      if (p.sprite) {
        const sz = Math.sqrt(p.sprite.length);
        const scale = TILE / sz;
        p.sprite.forEach((color, i) => {
          if (!color) return;
          const sx = i % sz; const sy = Math.floor(i / sz);
          ctx.fillStyle = color;
          ctx.fillRect(bx + sx * scale, by + sy * scale, scale, scale);
        });
      } else {
        ctx.fillStyle = '#6c63ff';
        ctx.fillRect(bx + 4, by + 4, TILE - 8, TILE - 8);
      }
      ctx.fillStyle = '#e8eaf6';
      ctx.font = '8px monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'alphabetic';
      ctx.fillText(p.pseudo, bx + TILE / 2, by - 3);
    }

    ctx.restore();
  }

  function addHousePlayer(p) {
    players.set(p.socketId, { ...p, isMe: false });
    addHouseChatMsg(`${p.pseudo} est entré`, null, '#6c63ff');
  }
  function removeHousePlayer(socketId) {
    const p = players.get(socketId);
    if (p) { players.delete(socketId); addHouseChatMsg(`${p.pseudo} est parti`, null, '#7b80a8'); }
  }
  function updateHousePlayerMove(socketId, x, y) {
    const p = players.get(socketId);
    if (p) { p.x = x; p.y = y; }
  }

  function addHouseChatMsg(text, pseudo, color) {
    const chat = document.getElementById('house-chat-messages');
    if (!chat) return;
    const div = document.createElement('div');
    div.className = 'chat-msg';
    if (pseudo) {
      div.innerHTML = `<span class="chat-name">${pseudo}:</span> <span class="chat-text">${text}</span>`;
    } else {
      div.innerHTML = `<span style="color:${color||'#7b80a8'};font-style:italic">${text}</span>`;
    }
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
  }

  function getCurrentWorldId() { return currentWorldId; }

  return {
    init, enter, applyTileUpdate,
    addHousePlayer, removeHousePlayer, updateHousePlayerMove,
    addHouseChatMsg, getCurrentWorldId
  };
})();

function leaveHouse() {
  WS.send({ type: 'LEAVE_WORLD' });
  showScreen('town');
}

function setEditorLayer(layer) { House.setEditorLayer.call({ setEditorLayer: House.setEditorLayer }, layer); }

// Hack pour transmettre le layer event correctement
function setEditorLayer(layer) {
  House._editorLayer = layer;
  const btns = document.querySelectorAll('.editor-mode-tabs .tab-btn');
  btns.forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');
  // Reconstruire la palette
  const tiles = layer === 'floor'
    ? [{ id: 'grass', emoji: '🟩' }, { id: 'dirt', emoji: '🟫' }, { id: 'stone', emoji: '⬜' }, { id: 'wood', emoji: '🟧' }, { id: 'water', emoji: '🟦' }, { id: 'sand', emoji: '🟨' }, { id: 'road', emoji: '⬛' }, { id: 'carpet', emoji: '🔴' }]
    : [{ id: 'tree', emoji: '🌲' }, { id: 'flower', emoji: '🌸' }, { id: 'rock', emoji: '🪨' }, { id: 'fence', emoji: '🚧' }, { id: 'computer', emoji: '💻' }, { id: 'chest', emoji: '📦' }, { id: 'plant', emoji: '🪴' }, { id: 'lamp', emoji: '🔆' }];

  const container = document.getElementById('tile-palette');
  container.innerHTML = '';
  tiles.forEach(t => {
    const btn = document.createElement('div');
    btn.className = 'tile-btn';
    btn.textContent = t.emoji;
    btn.onclick = () => {
      document.querySelectorAll('.tile-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
    };
    container.appendChild(btn);
  });
}

function setTool(tool) { House.setTool ? House.setTool(tool) : null; }

function houseChatKeydown(e) { if (e.key === 'Enter') sendHouseChat(); }
function sendHouseChat() {
  const input = document.getElementById('house-chat-input');
  const text = input.value.trim();
  if (!text) return;
  WS.send({ type: 'CHAT', text });
  input.value = '';
}
