/**
 * sprite-editor.js — Éditeur pixel-art pour le personnage
 */

const SpriteEditor = (() => {
  // Palette de 32 couleurs
  const PALETTE = [
    '#000000','#ffffff','#ff4d4d','#ff9933',
    '#ffff33','#66ff33','#33ccff','#9933ff',
    '#ff66cc','#00cc99','#996633','#666699',
    '#ffcccc','#ccffcc','#ccccff','#ffcc99',
    '#333333','#666666','#999999','#cccccc',
    '#1a1a2e','#16213e','#0f3460','#533483',
    '#e94560','#f5a623','#4ecca3','#45b7d1',
    '#ff6b9d','#c7f464','#81b29a','#f2cc8f'
  ];

  let size = 16;          // 8 ou 16
  let pixels = [];        // tableau taille*taille de couleurs hex
  let activeColor = '#ff4d4d';
  let isDrawing = false;
  let canvas, ctx, previewCanvas, previewCtx;

  function init() {
    canvas = document.getElementById('sprite-canvas');
    ctx = canvas.getContext('2d');
    previewCanvas = document.getElementById('sprite-preview');
    previewCtx = previewCanvas.getContext('2d');

    resetPixels();
    buildPalette();
    bindEvents();
    render();
  }

  function resetPixels() {
    pixels = Array(size * size).fill(null); // null = transparent
  }

  function setSpriteSize(newSize) {
    size = newSize;
    document.getElementById('btn-8x8').classList.toggle('active-size', size === 8);
    document.getElementById('btn-16x16').classList.toggle('active-size', size === 16);
    resetPixels();
    render();
  }

  function buildPalette() {
    const grid = document.getElementById('sprite-palette-grid');
    grid.innerHTML = '';
    PALETTE.forEach((color, i) => {
      const cell = document.createElement('div');
      cell.className = 'palette-cell' + (i === 1 ? ' selected' : '');
      cell.style.background = color;
      cell.title = color;
      cell.onclick = () => {
        document.querySelectorAll('.palette-cell').forEach(c => c.classList.remove('selected'));
        cell.classList.add('selected');
        activeColor = color;
        updateSwatch();
      };
      grid.appendChild(cell);
    });
    activeColor = PALETTE[1];
    updateSwatch();
  }

  function updateSwatch() {
    document.getElementById('active-color-swatch').style.background = activeColor;
  }

  function setCustomColor(hex) {
    activeColor = hex;
    updateSwatch();
    document.querySelectorAll('.palette-cell').forEach(c => c.classList.remove('selected'));
  }

  function bindEvents() {
    canvas.addEventListener('mousedown', e => { isDrawing = true; paint(e); });
    canvas.addEventListener('mousemove', e => { if (isDrawing) paint(e); });
    canvas.addEventListener('mouseup',   () => isDrawing = false);
    canvas.addEventListener('mouseleave',() => isDrawing = false);
    canvas.addEventListener('contextmenu', e => { e.preventDefault(); erase(e); });
    canvas.addEventListener('touchstart', e => { e.preventDefault(); isDrawing = true; paint(e.touches[0]); });
    canvas.addEventListener('touchmove',  e => { e.preventDefault(); if (isDrawing) paint(e.touches[0]); });
    canvas.addEventListener('touchend',   () => isDrawing = false);
  }

  function getCellCoords(e) {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const mx = (e.clientX - rect.left) * scaleX;
    const my = (e.clientY - rect.top)  * scaleY;
    const cellSize = canvas.width / size;
    const cx = Math.floor(mx / cellSize);
    const cy = Math.floor(my / cellSize);
    return { cx, cy };
  }

  function paint(e) {
    const { cx, cy } = getCellCoords(e);
    if (cx < 0 || cy < 0 || cx >= size || cy >= size) return;
    pixels[cy * size + cx] = activeColor;
    render();
  }

  function erase(e) {
    const { cx, cy } = getCellCoords(e);
    if (cx < 0 || cy < 0 || cx >= size || cy >= size) return;
    pixels[cy * size + cx] = null;
    render();
  }

  function clearSprite() { resetPixels(); render(); }

  function fillSprite() { pixels = pixels.map(p => p === null ? activeColor : p); render(); }

  function render() {
    const cellSize = canvas.width / size;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Damier transparent
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const check = (x + y) % 2 === 0 ? '#1c1f35' : '#141626';
        ctx.fillStyle = check;
        ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
      }
    }

    // Pixels
    for (let i = 0; i < pixels.length; i++) {
      if (!pixels[i]) continue;
      const x = i % size;
      const y = Math.floor(i / size);
      ctx.fillStyle = pixels[i];
      ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
    }

    // Grille
    ctx.strokeStyle = '#2a2f50';
    ctx.lineWidth = 0.5;
    for (let x = 0; x <= size; x++) {
      ctx.beginPath();
      ctx.moveTo(x * cellSize, 0);
      ctx.lineTo(x * cellSize, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y <= size; y++) {
      ctx.beginPath();
      ctx.moveTo(0, y * cellSize);
      ctx.lineTo(canvas.width, y * cellSize);
      ctx.stroke();
    }

    renderPreview();
  }

  function renderPreview() {
    const pw = previewCanvas.width;
    const ph = previewCanvas.height;
    const cellSize = pw / size;
    previewCtx.clearRect(0, 0, pw, ph);
    for (let i = 0; i < pixels.length; i++) {
      if (!pixels[i]) continue;
      const x = i % size;
      const y = Math.floor(i / size);
      previewCtx.fillStyle = pixels[i];
      previewCtx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
    }
  }

  // Dessiner un sprite (tableau de couleurs) sur un canvas donné
  function drawSpriteOnCanvas(spriteData, targetCanvas, targetSize) {
    if (!spriteData) return;
    const sz = Math.sqrt(spriteData.length);
    const ctx2 = targetCanvas.getContext('2d');
    ctx2.clearRect(0, 0, targetCanvas.width, targetCanvas.height);
    const cellSize = targetCanvas.width / sz;
    spriteData.forEach((color, i) => {
      if (!color) return;
      const x = i % sz;
      const y = Math.floor(i / sz);
      ctx2.fillStyle = color;
      ctx2.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
    });
  }

  async function saveSprite() {
    const result = await API.post('/api/sprite', { spriteData: pixels });
    if (result.error) { toast(result.error, true); return; }
    toast('✨ Sprite sauvegardé !');
    window.currentUser.sprite = pixels;
    return true;
  }

  function loadSprite(spriteData) {
    if (!spriteData) return;
    size = Math.sqrt(spriteData.length);
    pixels = [...spriteData];
    render();
  }

  function getPixels() { return [...pixels]; }

  return { init, setSpriteSize, clearSprite, fillSprite, saveSprite, loadSprite, drawSpriteOnCanvas, getPixels, setCustomColor };
})();
