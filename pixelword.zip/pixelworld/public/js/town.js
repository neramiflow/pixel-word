/**
 * town.js — Ville sandbox multijoueur
 */

const Town = (() => {
  // Dimensions de la carte
  const MAP_W = 40, MAP_H = 30;
  const TILE = 16; // px par tuile

  let canvas, ctx;
  let camera = { x: 0, y: 0 };
  let myPlayer = null;          // { socketId, userId, pseudo, sprite, x, y }
  let players = new Map();      // socketId → player
  let houses = [];              // { id, user_id, pseudo, x, y, world_id }
  let myHouse = null;
  let animFrame = null;
  let keys = {};

  // Tuiles de la ville (générées procéduralement)
  const townMap = generateTownMap();

  function generateTownMap() {
    const map = [];
    for (let y = 0; y < MAP_H; y++) {
      map[y] = [];
      for (let x = 0; x < MAP_W; x++) {
        // Routes centrales
        if (x === 20 || y === 15 || (x >= 8 && x <= 12 && y >= 5 && y <= 8)) {
          map[y][x] = 'road';
        } else if (x < 2 || x >= MAP_W - 2 || y < 2 || y >= MAP_H - 2) {
          map[y][x] = 'water';
        } else if ((x + y) % 7 === 0) {
          map[y][x] = 'tree';
        } else {
          map[y][x] = 'grass';
        }
      }
    }
    return map;
  }

  // Couleurs des tuiles
  const TILE_COLORS = {
    grass: '#2d5a27',
    road:  '#555566',
    water: '#1a3a5c',
    tree:  '#1a4a1a',
    house: '#7a4f3a',
    empty: '#2a3a1a'
  };
  const TILE_EMOJI = {
    tree:  '🌲',
    water: '🌊'
  };

  function init(canvasEl) {
    canvas = canvasEl;
    ctx = canvas.getContext('2d');

    // Clavier
    document.addEventListener('keydown', e => {
      if (document.getElementById('screen-town').classList.contains('active')) {
        keys[e.key] = true;
        handleKeyMove(e.key);
        if (e.key === 'Enter' || e.key === ' ') interactPlayer();
      }
    });
    document.addEventListener('keyup', e => keys[e.key] = false);

    // Clic sur la carte
    canvas.addEventListener('click', onCanvasClick);
    canvas.addEventListener('mousemove', onCanvasHover);
    canvas.addEventListener('mouseleave', () => {
      document.getElementById('town-tooltip').style.display = 'none';
    });

    startLoop();
  }

  function handleKeyMove(key) {
    switch(key) {
      case 'ArrowUp':    case 'z': case 'Z': movePlayer(0,-1); break;
      case 'ArrowDown':  case 's': case 'S': movePlayer(0,1);  break;
      case 'ArrowLeft':  case 'q': case 'Q': movePlayer(-1,0); break;
      case 'ArrowRight': case 'd': case 'D': movePlayer(1,0);  break;
    }
  }

  function setMyPlayer(p) {
    myPlayer = p;
    players.set(p.socketId, p);
    updateCamera();
  }

  function setPlayers(list) {
    players.clear();
    list.forEach(p => players.set(p.socketId, p));
    if (myPlayer) players.set(myPlayer.socketId, myPlayer);
    updatePlayersList();
  }

  function setHouses(list) {
    houses = list;
    myHouse = list.find(h => h.user_id === window.currentUser?.id) || null;
    updateHouseStatus();
  }

  function addPlayer(p) {
    players.set(p.socketId, p);
    updatePlayersList();
    addChatMsg(`${p.pseudo} a rejoint la ville`, null, '#6c63ff');
  }

  function removePlayer(socketId) {
    const p = players.get(socketId);
    if (p && p.socketId !== myPlayer?.socketId) {
      players.delete(socketId);
      updatePlayersList();
      addChatMsg(`${p.pseudo} a quitté la ville`, null, '#7b80a8');
    }
  }

  function updatePlayerMove(socketId, x, y) {
    const p = players.get(socketId);
    if (p) { p.x = x; p.y = y; }
  }

  function updateCamera() {
    if (!myPlayer) return;
    const cw = canvas.width, ch = canvas.height;
    camera.x = myPlayer.x * TILE - cw / 2 + TILE / 2;
    camera.y = myPlayer.y * TILE - ch / 2 + TILE / 2;
    camera.x = Math.max(0, Math.min(MAP_W * TILE - cw, camera.x));
    camera.y = Math.max(0, Math.min(MAP_H * TILE - ch, camera.y));
  }

  // Appel externe pour déplacer mon joueur
  function movePlayer(dx, dy) {
    if (!myPlayer) return;
    const nx = myPlayer.x + dx;
    const ny = myPlayer.y + dy;
    if (nx < 0 || ny < 0 || nx >= MAP_W || ny >= MAP_H) return;
    const tile = townMap[ny][nx];
    if (tile === 'water') return;
    myPlayer.x = nx;
    myPlayer.y = ny;
    updateCamera();
    WS.send({ type: 'MOVE', x: nx, y: ny });
  }

  function interactPlayer() {
    if (!myPlayer) return;
    // Chercher une maison adjacente
    for (const h of houses) {
      if (Math.abs(h.x - myPlayer.x) <= 1 && Math.abs(h.y - myPlayer.y) <= 1) {
        enterHouse(h);
        return;
      }
    }
    // Placer sa maison si pas encore faite
    if (!myHouse) {
      const tile = townMap[myPlayer.y]?.[myPlayer.x];
      if (tile === 'grass' || tile === 'empty') {
        placeHere();
      }
    }
  }

  async function placeHere() {
    if (!myPlayer || myHouse) return;
    const res = await API.post('/api/houses', { x: myPlayer.x, y: myPlayer.y });
    if (res.error) { toast(res.error, true); return; }
    myHouse = res.house;
    myHouse.pseudo = window.currentUser.pseudo;
    houses.push(myHouse);
    updateHouseStatus();
    toast('🏠 Maison placée ! Appuie sur Entrée pour entrer.');
  }

  function enterHouse(house) {
    WS.send({ type: 'ENTER_WORLD', worldId: house.world_id });
    House.enter(house);
  }

  function onCanvasClick(e) {
    const { tx, ty } = screenToTile(e);
    const house = houses.find(h => h.x === tx && h.y === ty);
    if (house) {
      enterHouse(house);
      return;
    }
    // Déplacer le personnage vers la case cliquée (simple pathfinding: 1 pas)
    if (myPlayer) {
      const dx = Math.sign(tx - myPlayer.x);
      const dy = Math.sign(ty - myPlayer.y);
      if (dx !== 0) movePlayer(dx, 0);
      else if (dy !== 0) movePlayer(0, dy);
    }
  }

  function onCanvasHover(e) {
    const { tx, ty } = screenToTile(e);
    const tooltip = document.getElementById('town-tooltip');
    const house = houses.find(h => h.x === tx && h.y === ty);
    if (house) {
      tooltip.textContent = `🏠 ${house.pseudo}`;
      tooltip.style.display = 'block';
      tooltip.style.left = (e.offsetX + 12) + 'px';
      tooltip.style.top  = (e.offsetY + 12) + 'px';
    } else {
      tooltip.style.display = 'none';
    }
  }

  function screenToTile(e) {
    return {
      tx: Math.floor((e.offsetX + camera.x) / TILE),
      ty: Math.floor((e.offsetY + camera.y) / TILE)
    };
  }

  // ─── Rendu ──────────────────────────────────────────────

  function startLoop() {
    function loop() {
      draw();
      animFrame = requestAnimationFrame(loop);
    }
    loop();
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.translate(-camera.x, -camera.y);

    // Tuiles
    const startX = Math.floor(camera.x / TILE);
    const startY = Math.floor(camera.y / TILE);
    const endX = Math.min(MAP_W, startX + Math.ceil(canvas.width / TILE) + 2);
    const endY = Math.min(MAP_H, startY + Math.ceil(canvas.height / TILE) + 2);

    for (let y = startY; y < endY; y++) {
      for (let x = startX; x < endX; x++) {
        const tile = townMap[y]?.[x] || 'grass';
        ctx.fillStyle = TILE_COLORS[tile] || TILE_COLORS.grass;
        ctx.fillRect(x * TILE, y * TILE, TILE, TILE);
      }
    }

    // Maisons
    for (const h of houses) {
      ctx.fillStyle = '#5a3a2a';
      ctx.fillRect(h.x * TILE, h.y * TILE, TILE, TILE);
      ctx.fillStyle = '#8b5a3c';
      ctx.fillRect(h.x * TILE + 2, h.y * TILE + 2, TILE - 4, TILE - 4);
      // Toit
      ctx.fillStyle = '#c0392b';
      ctx.beginPath();
      ctx.moveTo(h.x * TILE, h.y * TILE + 6);
      ctx.lineTo(h.x * TILE + TILE / 2, h.y * TILE);
      ctx.lineTo(h.x * TILE + TILE, h.y * TILE + 6);
      ctx.closePath();
      ctx.fill();
      // Porte
      ctx.fillStyle = '#2c1810';
      ctx.fillRect(h.x * TILE + 6, h.y * TILE + 9, 4, 7);
      // Nom
      if (h.pseudo) {
        ctx.fillStyle = '#fff';
        ctx.font = '6px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(h.pseudo.slice(0, 6), h.x * TILE + TILE / 2, h.y * TILE - 3);
        ctx.textAlign = 'left';
      }
    }

    // Joueurs
    for (const [sid, p] of players) {
      const px = p.x * TILE;
      const py = p.y * TILE;
      const isMe = myPlayer && sid === myPlayer.socketId;

      if (p.sprite && p.sprite.length > 0) {
        // Dessiner le sprite pixel-art
        const sz = Math.sqrt(p.sprite.length);
        const scale = TILE / sz;
        p.sprite.forEach((color, i) => {
          if (!color) return;
          const sx = i % sz;
          const sy = Math.floor(i / sz);
          ctx.fillStyle = color;
          ctx.fillRect(px + sx * scale, py + sy * scale, scale, scale);
        });
      } else {
        // Fallback : carré coloré
        ctx.fillStyle = isMe ? '#43e89e' : '#6c63ff';
        ctx.fillRect(px + 2, py + 2, TILE - 4, TILE - 4);
        // Yeux
        ctx.fillStyle = '#000';
        ctx.fillRect(px + 4, py + 5, 2, 2);
        ctx.fillRect(px + 10, py + 5, 2, 2);
      }

      // Pseudo au-dessus
      ctx.fillStyle = isMe ? '#43e89e' : '#e8eaf6';
      ctx.font = '6px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(p.pseudo, px + TILE / 2, py - 2);
      ctx.textAlign = 'left';

      // Indicateur "moi"
      if (isMe) {
        ctx.strokeStyle = '#43e89e';
        ctx.lineWidth = 1;
        ctx.strokeRect(px, py, TILE, TILE);
      }
    }

    ctx.restore();
  }

  // ─── UI ─────────────────────────────────────────────────

  function updatePlayersList() {
    const el = document.getElementById('players-list');
    if (!el) return;
    el.innerHTML = '';
    for (const [sid, p] of players) {
      const isMe = myPlayer && sid === myPlayer.socketId;
      const div = document.createElement('div');
      div.className = 'player-item' + (isMe ? ' is-me' : '');

      // Mini-sprite
      const c = document.createElement('canvas');
      c.width = 16; c.height = 16;
      SpriteEditor.drawSpriteOnCanvas(p.sprite, c);
      div.appendChild(c);

      const span = document.createElement('span');
      span.textContent = p.pseudo + (isMe ? ' (moi)' : '');
      div.appendChild(span);
      el.appendChild(div);
    }
    document.getElementById('hud-online').textContent = `👥 ${players.size}`;
  }

  function updateHouseStatus() {
    const el = document.getElementById('house-status');
    if (!el) return;
    if (myHouse) {
      el.innerHTML = `<span class="house-placed">✅ Maison placée en (${myHouse.x}, ${myHouse.y})</span>`;
    } else {
      el.innerHTML = `<span style="color:var(--text-muted)">Pas encore de maison.<br>Déplace-toi sur une case verte et appuie sur Entrée ou ✦</span>`;
    }
  }

  function addChatMsg(text, pseudo = null, color = null) {
    const chat = document.getElementById('chat-messages');
    if (!chat) return;
    const div = document.createElement('div');
    div.className = 'chat-msg';
    if (pseudo) {
      div.innerHTML = `<span class="chat-name">${pseudo}:</span> <span class="chat-text">${text}</span>`;
    } else {
      div.innerHTML = `<span style="color:${color || '#7b80a8'};font-style:italic">${text}</span>`;
    }
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
  }

  function updateSpriteInList(userId, sprite) {
    for (const [, p] of players) {
      if (p.userId === userId) { p.sprite = sprite; }
    }
    updatePlayersList();
  }

  return {
    init, setMyPlayer, setPlayers, setHouses,
    addPlayer, removePlayer, updatePlayerMove,
    addChatMsg, movePlayer, interactPlayer, updateSpriteInList,
    getMyHouse: () => myHouse
  };
})();

// Fonctions globales appelées depuis le HTML
function movePlayer(dx, dy) { Town.movePlayer(dx, dy); }
function interactPlayer()   { Town.interactPlayer(); }

function chatKeydown(e) { if (e.key === 'Enter') sendChat(); }
function sendChat() {
  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  if (!text) return;
  WS.send({ type: 'CHAT', text });
  input.value = '';
}
