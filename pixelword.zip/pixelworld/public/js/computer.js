/**
 * computer.js — Ordinateur personnel + CodeNet
 */

function openComputer() {
  const modal = document.getElementById('modal-computer');
  modal.classList.add('open');
  compTab('worlds');
  loadWorldsList();
}

function closeComputer() {
  document.getElementById('modal-computer').classList.remove('open');
}

function closeComputerIfBg(e) {
  if (e.target === document.getElementById('modal-computer')) closeComputer();
}

function compTab(tab) {
  document.querySelectorAll('.comp-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('#modal-computer .tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`comp-${tab}`).classList.add('active');
  event.target.classList.add('active');

  if (tab === 'codenet') loadCodenet();
  if (tab === 'worlds') loadWorldsList();
}

async function loadWorldsList() {
  const res = await API.get('/api/worlds');
  const list = document.getElementById('worlds-list');
  if (!list) return;

  if (res.error || !res.length) {
    list.innerHTML = '<div style="color:var(--text-muted);font-size:11px;text-align:center;padding:20px">Aucun monde. Crée-en un !</div>';
    return;
  }

  list.innerHTML = '';
  res.forEach(world => {
    const div = document.createElement('div');
    div.className = 'world-item';
    const typeLabel = world.type === 'house' ? '🏠 Maison' : '🌐 Monde';
    div.innerHTML = `
      <div>
        <div class="world-item-name">${world.name}</div>
        <div class="world-item-meta">${typeLabel} • ID: ${world.id.slice(0, 8)}...</div>
      </div>
      <div style="display:flex;gap:6px;">
        <button class="btn-sm" onclick="enterWorldFromComputer('${world.id}', '${world.name}')">🚪 Entrer</button>
        <button class="btn-sm" onclick="shareWorldFromComputer('${world.id}', '${world.name}')">📤 Partager</button>
      </div>
    `;
    list.appendChild(div);
  });
}

async function createNewWorld() {
  const name = prompt('Nom du nouveau monde :');
  if (!name || !name.trim()) return;

  const res = await API.post('/api/worlds', { name: name.trim() });
  if (res.error) { toast(res.error, true); return; }

  toast(`🌐 Monde "${res.world.name}" créé !`);
  loadWorldsList();
}

function enterWorldFromComputer(worldId, name) {
  closeComputer();
  // Simuler l'entrée dans un monde custom
  WS.send({ type: 'ENTER_WORLD', worldId });
  document.getElementById('house-world-name').textContent = `🌐 ${name}`;

  // Charger les tuiles du monde
  API.get(`/api/worlds/${worldId}`).then(res => {
    if (res.error) return;
    House._worldId = worldId;
    // Mettre à jour le monde courant de House
    // Méthode simplifiée : réutiliser l'écran house
  });
  showScreen('house');
}

async function shareWorldFromComputer(worldId, name) {
  const title = prompt('Titre pour CodeNet :', name);
  if (!title) return;

  const res = await API.post('/api/codenet', { worldId, title: title.trim() });
  if (res.error) { toast(res.error, true); return; }
  toast('📡 Monde partagé sur CodeNet !');
}

function shareCurrentWorld() {
  const worldId = House.getCurrentWorldId ? House.getCurrentWorldId() : null;
  if (!worldId) { toast('Aucun monde actif', true); return; }
  shareWorldFromComputer(worldId, 'Mon monde');
}

async function loadCodenet() {
  const res = await API.get('/api/codenet');
  const list = document.getElementById('codenet-list');
  if (!list) return;

  if (!Array.isArray(res) || !res.length) {
    list.innerHTML = `
      <div style="text-align:center;padding:30px;color:var(--text-muted)">
        <div style="font-size:32px;margin-bottom:12px">📡</div>
        <div>Aucun projet sur CodeNet.</div>
        <div style="font-size:11px;margin-top:6px">Partage un monde depuis "Mes Mondes" !</div>
      </div>`;
    return;
  }

  list.innerHTML = '';
  res.forEach(post => {
    const date = new Date(post.created_at).toLocaleDateString('fr-FR');
    const div = document.createElement('div');
    div.className = 'codenet-item';
    div.innerHTML = `
      <div class="codenet-item-title">📦 ${post.title}</div>
      <div class="codenet-item-meta">Par ${post.pseudo} • ${date}</div>
      <div style="margin-top:8px;display:flex;gap:6px;">
        <button class="btn-sm" onclick="previewCodenet('${post.id}')">👁 Aperçu</button>
        <button class="btn-sm" onclick="copyCodenet('${post.id}')">📋 Copier</button>
      </div>
    `;
    list.appendChild(div);
  });
}

// Stocker les posts en mémoire pour aperçu/copie
let _codenetPosts = [];
async function refreshCodenetPosts() {
  _codenetPosts = await API.get('/api/codenet');
}

function previewCodenet(postId) {
  API.get('/api/codenet').then(posts => {
    const post = posts.find(p => p.id === postId);
    if (!post) return;
    const preview = JSON.parse(post.code);
    alert(`Monde: ${preview.world.name}\nTuiles: ${preview.tiles.length}\nType: ${preview.world.type}`);
  });
}

function copyCodenet(postId) {
  API.get('/api/codenet').then(posts => {
    const post = posts.find(p => p.id === postId);
    if (!post) return;
    navigator.clipboard?.writeText(post.code).then(() => toast('📋 Code copié !'))
      .catch(() => toast('Copie manuelle nécessaire'));
  });
}
