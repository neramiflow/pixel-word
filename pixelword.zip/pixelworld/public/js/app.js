/**
 * app.js — Point d'entrée principal, WebSocket, gestion des écrans
 */

// ═══════════════════════════════════════════════════════════
// ÉTAT GLOBAL
// ═══════════════════════════════════════════════════════════
window.currentUser = null;

// ═══════════════════════════════════════════════════════════
// GESTION DES ÉCRANS
// ═══════════════════════════════════════════════════════════
function showScreen(name) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById(`screen-${name}`);
  if (el) el.classList.add('active');
}

function showTab(tab) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.getElementById(`tab-${tab}`)?.classList.add('active');
  event.target.classList.add('active');
}

// ═══════════════════════════════════════════════════════════
// AUTHENTIFICATION
// ═══════════════════════════════════════════════════════════
async function doLogin() {
  const pseudo    = document.getElementById('login-pseudo').value.trim();
  const password  = document.getElementById('login-password').value;
  const errEl     = document.getElementById('login-error');
  errEl.textContent = '';

  const res = await API.post('/api/login', { pseudo, password });
  if (res.error) { errEl.textContent = res.error; return; }

  window.currentUser = res.user;
  afterLogin();
}

async function doRegister() {
  const pseudo    = document.getElementById('reg-pseudo').value.trim();
  const password  = document.getElementById('reg-password').value;
  const errEl     = document.getElementById('reg-error');
  errEl.textContent = '';

  const res = await API.post('/api/register', { pseudo, password });
  if (res.error) { errEl.textContent = res.error; return; }

  window.currentUser = res.user;
  afterLogin();
}

function afterLogin() {
  if (!window.currentUser.sprite) {
    showScreen('sprite');
    SpriteEditor.init();
  } else {
    goToTown();
  }
}

async function doLogout() {
  await API.post('/api/logout', {});
  WS.disconnect();
  window.currentUser = null;
  showScreen('auth');
}

// ═══════════════════════════════════════════════════════════
// ÉDITEUR DE SPRITE
// ═══════════════════════════════════════════════════════════
function setSpriteSize(n) { SpriteEditor.setSpriteSize(n); }
function clearSprite()    { SpriteEditor.clearSprite(); }
function fillSprite()     { SpriteEditor.fillSprite(); }
function setCustomColor(v){ SpriteEditor.setCustomColor(v); }

async function saveSprite() {
  const ok = await SpriteEditor.saveSprite();
  if (ok) goToTown();
}
function skipSprite() { goToTown(); }

function showSpriteEditor() {
  showScreen('sprite');
  SpriteEditor.init();
  if (window.currentUser?.sprite) SpriteEditor.loadSprite(window.currentUser.sprite);
}

// ═══════════════════════════════════════════════════════════
// CONNEXION WEBSOCKET
// ═══════════════════════════════════════════════════════════
const WS = (() => {
  let ws = null;
  let reconnectTimer = null;

  function connect() {
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    ws = new WebSocket(`${proto}://${location.host}`);

    ws.onopen = () => {
      console.log('[WS] Connecté');
      clearTimeout(reconnectTimer);
    };

    ws.onmessage = (e) => {
      let msg;
      try { msg = JSON.parse(e.data); } catch { return; }
      handleWSMessage(msg);
    };

    ws.onclose = () => {
      console.log('[WS] Déconnecté, reconnexion...');
      reconnectTimer = setTimeout(connect, 2000);
    };

    ws.onerror = (err) => console.error('[WS] Erreur', err);
  }

  function send(msg) {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(msg));
    }
  }

  function disconnect() {
    clearTimeout(reconnectTimer);
    if (ws) { ws.onclose = null; ws.close(); ws = null; }
  }

  return { connect, send, disconnect };
})();

// ─── Traitement des messages WebSocket ───────────────────

function handleWSMessage(msg) {
  switch (msg.type) {

    case 'INIT': {
      // Initialisation : liste des joueurs et maisons
      const me = msg.players.find(p => p.socketId === msg.socketId) || msg.player;
      if (me) Town.setMyPlayer(me);
      Town.setPlayers(msg.players);
      Town.setHouses(msg.houses);

      // Mettre à jour le HUD
      document.getElementById('hud-pseudo').textContent = window.currentUser.pseudo;
      const hudSprite = document.getElementById('hud-sprite');
      if (window.currentUser.sprite) {
        SpriteEditor.drawSpriteOnCanvas(window.currentUser.sprite, hudSprite);
      }
      break;
    }

    case 'PLAYER_JOINED': {
      const screen = document.querySelector('.screen.active')?.id;
      if (screen === 'screen-town') {
        Town.addPlayer(msg.player);
      } else if (screen === 'screen-house') {
        House.addHousePlayer(msg.player);
      }
      break;
    }

    case 'PLAYER_LEFT': {
      Town.removePlayer(msg.socketId);
      House.removeHousePlayer(msg.socketId);
      break;
    }

    case 'PLAYER_MOVED': {
      const screen = document.querySelector('.screen.active')?.id;
      if (screen === 'screen-town') {
        Town.updatePlayerMove(msg.socketId, msg.x, msg.y);
      } else {
        House.updateHousePlayerMove(msg.socketId, msg.x, msg.y);
      }
      break;
    }

    case 'PLAYER_SPRITE_UPDATE': {
      Town.updateSpriteInList(msg.userId, msg.sprite);
      break;
    }

    case 'HOUSE_PLACED': {
      Town.setHouses([...Town.getMyHouse ? [Town.getMyHouse()] : [], msg.house]);
      // Refresh houses
      API.get('/api/houses').then(houses => Town.setHouses(houses));
      break;
    }

    case 'TILE_UPDATE': {
      House.applyTileUpdate(msg);
      break;
    }

    case 'WORLD_STATE': {
      // Nouveau monde : charger les tuiles
      console.log('[WS] World state reçu', msg.worldId);
      break;
    }

    case 'RETURNED_TO_TOWN': {
      Town.setPlayers(msg.players);
      showScreen('town');
      break;
    }

    case 'CHAT': {
      const screen = document.querySelector('.screen.active')?.id;
      if (screen === 'screen-town') {
        Town.addChatMsg(msg.text, msg.pseudo);
      } else if (screen === 'screen-house') {
        House.addHouseChatMsg(msg.text, msg.pseudo);
      }
      break;
    }

    case 'ERROR':
      toast(msg.message, true);
      break;
  }
}

// ═══════════════════════════════════════════════════════════
// ALLER EN VILLE
// ═══════════════════════════════════════════════════════════
function goToTown() {
  showScreen('town');
  Town.init(document.getElementById('town-canvas'));
  House.init(document.getElementById('house-canvas'));
  WS.connect();
}

// ═══════════════════════════════════════════════════════════
// INIT AU CHARGEMENT
// ═══════════════════════════════════════════════════════════
window.addEventListener('DOMContentLoaded', async () => {
  // Vérifier si déjà connecté
  const res = await API.get('/api/me');
  if (res.id) {
    window.currentUser = res;
    goToTown();
  } else {
    showScreen('auth');
  }

  // Touches Enter sur les formulaires
  ['login-pseudo', 'login-password'].forEach(id => {
    document.getElementById(id)?.addEventListener('keydown', e => {
      if (e.key === 'Enter') doLogin();
    });
  });
  ['reg-pseudo', 'reg-password'].forEach(id => {
    document.getElementById(id)?.addEventListener('keydown', e => {
      if (e.key === 'Enter') doRegister();
    });
  });
});
